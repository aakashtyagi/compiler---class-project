package comp;

import java.util.*;
public class STC extends Object{

	String type;
	String value;
	public STC(String t, String v){
		type = t;
		value = v;
	}
}
